package inc.robertouc.com.imc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.regex.Matcher;

public class MainActivity extends AppCompatActivity {
    private EditText CampoPeso;
    private EditText CampoEstatura;
    private Button BotonCalcular;
    private Button BotonLimpiar;
    private TextView ImcTextView;
    private TextView NutricionalTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CampoPeso = findViewById(R.id.campo_peso);
        CampoEstatura = findViewById(R.id.campo_estatura);
        BotonCalcular = findViewById(R.id.boton_calcular);
        NutricionalTextView=findViewById(R.id.nutricional_text_view);
        ImcTextView=findViewById(R.id.imc_text_view);
        BotonCalcular.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String s = CampoPeso.getText().toString();
                double peso = Double.parseDouble(s);
                s = CampoEstatura.getText().toString();
                double estatura = Double.parseDouble(s);
                double imc = peso/ Math.pow(estatura,2);
                ImcTextView.setText(Double.toString(imc));

                if(imc<18.5){
                    NutricionalTextView.setText("Usted tiene peso bajo");
                } else if(imc>=18.5 || imc<24.99){
                    NutricionalTextView.setText("Usted tiene peso normal");
                } else if(imc>=25.0 || imc<29.99){
                    NutricionalTextView.setText("Usted tiene sobrepeso");
                } else if(imc>=30.0 || imc<39.99){
                    NutricionalTextView.setText("Usted tiene obesidad");
                } else{
                    NutricionalTextView.setText("Usted tiene obesidad extrema");
                }
            }
        });

        BotonLimpiar = findViewById(R.id.boton_limpiar);
        BotonLimpiar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CampoPeso.setText(" ");
                CampoEstatura.setText(" ");
                ImcTextView.setText(" ");
                NutricionalTextView.setText(" ");
            }
        });






    }
}
